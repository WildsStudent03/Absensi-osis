<?php
$conn = new mysqli("localhost", "root", "", "absensi_osis");
//$conn = new mysqli("sql102.infinityfree.com", "if0_40376870", "PooJyYpOJlkZ", "if0_40376870_absensi_osis");

?>